from django.shortcuts import render
from django.shortcuts import render, get_object_or_404, redirect
from .models import Product, Category
from .forms import ProductForm, CategoryForm, ProductSearchForm

def products_view(request):
    search_form = ProductSearchForm(request.GET)
    if search_form.is_valid():
        query = search_form.cleaned_data['query']
        products = Product.objects.filter(title__icontains=query, stock__gt=0).order_by('category__name', 'title')
    else:
        products = Product.objects.filter(stock__gt=0).order_by('category__name', 'title')
    return render(request, 'products.html', {'products': products, 'search_form': search_form})

def product_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    return render(request, 'product_detail.html', {'product': product})

def product_add_view(request):
    if request.method == 'POST':
        form = ProductForm(request.POST)
        if form.is_valid():
            product = form.save()
            return redirect('product_view', pk=product.pk)
    else:
        form = ProductForm()
    return render(request, 'product_form.html', {'form': form})

def product_edit_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        form = ProductForm(request.POST, instance=product)
        if form.is_valid():
            form.save()
            return redirect('product_view', pk=product.pk)
    else:
        form = ProductForm(instance=product)
    return render(request, 'product_form.html', {'form': form})

def product_delete_view(request, pk):
    product = get_object_or_404(Product, pk=pk)
    if request.method == 'POST':
        product.delete()
        return redirect('products_view')
    return render(request, 'product_confirm_delete.html', {'product': product})

def categories_view(request):
    categories = Category.objects.all()
    return render(request, 'categories.html', {'categories': categories})

def category_add_view(request):
    if request.method == 'POST':
        form = CategoryForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('categories_view')
    else:
        form = CategoryForm()
    return render(request, 'category_form.html', {'form': form})

def category_edit_view(request, pk):
    category = get_object_or_404(Category, pk=pk)
    if request.method == 'POST':
        form = CategoryForm(request.POST, instance=category)
        if form.is_valid():
            form.save()
            return redirect('categories_view')
    else:
        form = CategoryForm(instance=category)
    return render(request, 'category_form.html', {'form': form})

def products_by_category_view(request, category_name):
    category = get_object_or_404(Category, name=category_name)
    products = Product.objects.filter(category=category, stock__gt=0).order_by('title')
    search_form = ProductSearchForm(request.GET)
    if search_form.is_valid():
        query = search_form.cleaned_data['query']
        products = products.filter(title__icontains=query)
    return render(request, 'products_by_category.html', {'category': category, 'products': products, 'search_form': search_form})

